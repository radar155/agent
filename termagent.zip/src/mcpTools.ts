import { MultiServerMCPClient } from "@langchain/mcp-adapters";

const client = new MultiServerMCPClient({  
    suitableAreas: {
        transport: "http",  // HTTP-based remote server
        // Ensure you start your weather server on port 8000
        url: "https://dev.energeea.com/mcp_suitableareasmanager/mcp",
    },
});

export const mcpTools = await client.getTools()